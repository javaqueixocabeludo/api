package com.rental.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.rental.api.model.Equipamento;
import com.rental.api.service.EquipamentoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/equipamentos")
public class EquipamentoController {

    private final EquipamentoService equipamentoService;

    public EquipamentoController(EquipamentoService equipamentoService) {
        this.equipamentoService = equipamentoService;
    }

    @GetMapping
    public List<Equipamento> listar() {
        return equipamentoService.listarTodos();
    }

    @GetMapping("/{id}")
    public Equipamento buscarPorId(@PathVariable Integer id) {
        return equipamentoService.buscarPorId(id);
    }

    @GetMapping("/categoria/{idCategoria}")
    public List<Equipamento> listarPorCategoria(@PathVariable Integer idCategoria) {
        return equipamentoService.listarPorCategoria(idCategoria);
    }

    @GetMapping("/estoque-baixo")
    public List<Equipamento> listarComEstoqueBaixo() {
        return equipamentoService.listarComEstoqueBaixo();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Equipamento criar(@Valid @RequestBody Equipamento equipamento) {
        return equipamentoService.criar(equipamento);
    }

    @PutMapping("/{id}")
    public Equipamento atualizar(@PathVariable Integer id, @Valid @RequestBody Equipamento equipamento) {
        return equipamentoService.atualizar(id, equipamento);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Integer id) {
        equipamentoService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
