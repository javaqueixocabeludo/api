package com.rental.api.controller;

import com.rental.api.dto.MovimentacaoRequest;
import com.rental.api.model.Movimentacao;
import com.rental.api.service.MovimentacaoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/movimentacoes")
public class MovimentacaoController {

    private final MovimentacaoService movimentacaoService;

    public MovimentacaoController(MovimentacaoService movimentacaoService) {
        this.movimentacaoService = movimentacaoService;
    }

    @GetMapping
    public List<Movimentacao> listar() {
        return movimentacaoService.listarTodas();
    }

    @GetMapping("/{id}")
    public Movimentacao buscarPorId(@PathVariable Integer id) {
        return movimentacaoService.buscarPorId(id);
    }

    @GetMapping("/equipamento/{idEquipamento}")
    public List<Movimentacao> listarPorEquipamento(@PathVariable Integer idEquipamento) {
        return movimentacaoService.listarPorEquipamento(idEquipamento);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<Movimentacao> listarPorUsuario(@PathVariable Integer idUsuario) {
        return movimentacaoService.listarPorUsuario(idUsuario);
    }

    /**
     * Registra uma ENTRADA ou SAIDA. O estoque do equipamento e ajustado
     * automaticamente pelo service dentro da mesma transacao.
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Movimentacao registrar(@Valid @RequestBody MovimentacaoRequest request) {
        return movimentacaoService.registrar(request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Integer id) {
        movimentacaoService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
