package com.rental.api.dto;

import java.time.LocalDateTime;

import com.rental.api.model.Movimentacao;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MovimentacaoRequest {

    @NotNull(message = "O id do equipamento e obrigatorio")
    private Integer idEquipamento;

    @NotNull(message = "O id do usuario e obrigatorio")
    private Integer idUsuario;

    private LocalDateTime dataMovimentacao;

    @NotNull(message = "O tipo de movimentacao e obrigatorio")
    private Movimentacao tipoMovimentacao;

    @NotNull(message = "A quantidade e obrigatoria")
    @Min(value = 1, message = "A quantidade deve ser maior que zero")
    private Integer quantidade;
}
