package com.rental.api.util;

import com.rental.api.model.Equipamento;

import java.util.List;

public class OrdenadorEquipamentos {

    public static void ordenarPorNome(List<Equipamento> equipamentos) {
        int n = equipamentos.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                Equipamento atual = equipamentos.get(j);
                Equipamento proximo = equipamentos.get(j + 1);
                if (atual.getNome().compareToIgnoreCase(proximo.getNome()) > 0) {
                    equipamentos.set(j, proximo);
                    equipamentos.set(j + 1, atual);
                }
            }
        }
    }
}
