package com.rental.api.model;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "equipamentos")
@Data
@NoArgsConstructor
public class Equipamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_equipamento")
    private Integer idEquipamento;

    @NotBlank(message = "O nome do equipamento e obrigatorio")
    @Column(nullable = false, length = 100)
    private String nome;

    @Column(length = 50)
    private String marca;

    @Column(length = 100)
    private String modelo;

    @Column(length = 50)
    private String potencia;

    @Column(length = 50)
    private String material;

    @Column(precision = 6, scale = 2)
    private BigDecimal peso;

    @Column(length = 100)
    private String dimensoes;

    @Column(length = 50)
    private String cor;

    public Equipamento(String cor, String dimensoes, Integer idEquipamento, String marca, String material, String modelo, String nome, BigDecimal peso, String potencia) {
        this.cor = cor;
        this.dimensoes = dimensoes;
        this.idEquipamento = idEquipamento;
        this.marca = marca;
        this.material = material;
        this.modelo = modelo;
        this.nome = nome;
        this.peso = peso;
        this.potencia = potencia;
    }

    public Integer getIdEquipamento() {
        return idEquipamento;
    }

    public void setIdEquipamento(Integer idEquipamento) {
        this.idEquipamento = idEquipamento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPotencia() {
        return potencia;
    }

    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public String getDimensoes() {
        return dimensoes;
    }

    public void setDimensoes(String dimensoes) {
        this.dimensoes = dimensoes;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }


}
