package com.rental.api.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "movimentacoes")
@Data
@NoArgsConstructor
public class Movimentacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_movimentacao")
    private Integer idMovimentacao;

    @Column(name = "idequipamento", nullable = false)
    private Equipamento idequipamento;

    @Column(name = "id_usuario", nullable = false)
    private Usuario id_usuario ;

    @Column(name = "data_movimentacao", nullable = false)
    private LocalDateTime dataMovimentacao;

    @Column(name = "tipomovimentacao", nullable = false)
    private Movimentacao tipomovimentacao ;

    @Column(nullable = false)
    private Integer quantidade;

    public Movimentacao(LocalDateTime dataMovimentacao, Integer idMovimentacao, Usuario id_usuario, Equipamento idequipamento, Integer quantidade, Movimentacao tipomovimentacao) {
        this.dataMovimentacao = dataMovimentacao;
        this.idMovimentacao = idMovimentacao;
        this.id_usuario = id_usuario;
        this.idequipamento = idequipamento;
        this.quantidade = quantidade;
        this.tipomovimentacao = tipomovimentacao;
    }

    public Integer getIdMovimentacao() {
        return idMovimentacao;
    }

    public void setIdMovimentacao(Integer idMovimentacao) {
        this.idMovimentacao = idMovimentacao;
    }

    public Equipamento getIdequipamento() {
        return idequipamento;
    }

    public void setIdequipamento(Equipamento idequipamento) {
        this.idequipamento = idequipamento;
    }

    public Usuario getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(Usuario id_usuario) {
        this.id_usuario = id_usuario;
    }

    public LocalDateTime getDataMovimentacao() {
        return dataMovimentacao;
    }

    public void setDataMovimentacao(LocalDateTime dataMovimentacao) {
        this.dataMovimentacao = dataMovimentacao;
    }

    public Movimentacao getTipomovimentacao() {
        return tipomovimentacao;
    }

    public void setTipomovimentacao(Movimentacao tipomovimentacao) {
        this.tipomovimentacao = tipomovimentacao;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }


}
