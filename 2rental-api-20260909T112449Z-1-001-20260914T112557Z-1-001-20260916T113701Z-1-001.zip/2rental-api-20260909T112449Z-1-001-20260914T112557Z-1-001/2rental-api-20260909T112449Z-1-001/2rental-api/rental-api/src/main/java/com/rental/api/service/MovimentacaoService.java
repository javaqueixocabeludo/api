package com.rental.api.service;

import com.rental.api.dto.MovimentacaoRequest;
import com.rental.api.exception.BusinessException;
import com.rental.api.exception.ResourceNotFoundException;
import com.rental.api.model.Equipamento;
import com.rental.api.model.Movimentacao;
import com.rental.api.model.Usuario;
import com.rental.api.repository.EquipamentoRepository;
import com.rental.api.repository.MovimentacaoRepository;
import com.rental.api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MovimentacaoService {

    private final MovimentacaoRepository movimentacaoRepository;
    private final EquipamentoRepository equipamentoRepository;
    private final UsuarioRepository usuarioRepository;

    public MovimentacaoService(MovimentacaoRepository movimentacaoRepository,
                                EquipamentoRepository equipamentoRepository,
                                UsuarioRepository usuarioRepository) {
        this.movimentacaoRepository = movimentacaoRepository;
        this.equipamentoRepository = equipamentoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public List<Movimentacao> listarTodas() {
        return movimentacaoRepository.findAll();
    }

    public Movimentacao buscarPorId(Integer id) {
        return movimentacaoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Movimentacao nao encontrada com id: " + id));
    }

    public List<Movimentacao> listarPorEquipamento(Integer idEquipamento) {
        return movimentacaoRepository.findByEquipamento_IdEquipamento(idEquipamento);
    }

    public List<Movimentacao> listarPorUsuario(Integer idUsuario) {
        return movimentacaoRepository.findByUsuario_IdUsuario(idUsuario);
    }

    @Transactional
    public Movimentacao registrar(MovimentacaoRequest request) {
        Equipamento equipamento = equipamentoRepository.findById(request.getIdEquipamento())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Equipamento nao encontrado com id: " + request.getIdEquipamento()));

        Usuario usuario = usuarioRepository.findById(request.getIdUsuario())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario nao encontrado com id: " + request.getIdUsuario()));

        ajustarEstoque(equipamento, request.getTipoMovimentacao(), request.getQuantidade());
        equipamentoRepository.save(equipamento);

        Movimentacao movimentacao = new Movimentacao();
        movimentacao.setEquipamento(equipamento);
        movimentacao.setUsuario(usuario);
        movimentacao.setTipoMovimentacao(request.getTipoMovimentacao());
        movimentacao.setQuantidade(request.getQuantidade());
        movimentacao.setDataMovimentacao(
                request.getDataMovimentacao() != null ? request.getDataMovimentacao() : LocalDateTime.now()
        );

        return movimentacaoRepository.save(movimentacao);
    }

    private void ajustarEstoque(Equipamento equipamento, Movimentacao tipo, Integer quantidade) {
        if (tipo == Movimentacao.ENTRADA) {
            equipamento.setQuantidadeDisponivel(equipamento.getQuantidadeDisponivel() + quantidade);
        } else { // SAIDA
            int disponivelAposSaida = equipamento.getQuantidadeDisponivel() - quantidade;
            if (disponivelAposSaida < 0) {
                throw new BusinessException(
                        "Estoque insuficiente para '" + equipamento.getNome() + "'. Disponivel: "
                                + equipamento.getQuantidadeDisponivel() + ", solicitado: " + quantidade
                );
            }
            equipamento.setQuantidadeDisponivel(disponivelAposSaida);
        }
    }

    @Transactional
    public void excluir(Integer id) {
        Movimentacao movimentacao = buscarPorId(id);
        Equipamento equipamento = movimentacao.getEquipamento();

        Movimentacao Inverso = movimentacao.getMovimentacao() == Movimentacao.ENTRADA
                ? Movimentacao.SAIDA
                : Movimentacao.ENTRADA;

        ajustarEstoque(equipamento, Inverso, movimentacao.getQuantidade());
        equipamentoRepository.save(equipamento);

        movimentacaoRepository.delete(movimentacao);
    }
}
