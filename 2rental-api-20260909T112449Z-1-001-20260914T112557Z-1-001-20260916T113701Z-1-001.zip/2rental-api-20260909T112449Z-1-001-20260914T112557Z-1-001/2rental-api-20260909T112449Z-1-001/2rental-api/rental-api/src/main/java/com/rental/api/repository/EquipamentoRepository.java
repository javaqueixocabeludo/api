package com.rental.api.repository;

import com.rental.api.model.Equipamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EquipamentoRepository extends JpaRepository<Equipamento, Integer> {

    List<Equipamento> findByCategoria_IdCategoria(Integer idCategoria);

    List<Equipamento> findByNomeContainingIgnoreCase(String termo);

    @Query("SELECT e FROM Equipamento e WHERE e.quantidadeDisponivel <= e.quantidadeMinima")
    List<Equipamento> findComEstoqueBaixo();
}
