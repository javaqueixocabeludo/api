package com.rental.api.repository;

import com.rental.api.model.Movimentacao;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MovimentacaoRepository extends JpaRepository<Movimentacao, Integer> {

    List<Movimentacao> findByEquipamento_IdEquipamento(Integer idEquipamento);

    List<Movimentacao> findByUsuario_IdUsuario(Integer idUsuario);
}
