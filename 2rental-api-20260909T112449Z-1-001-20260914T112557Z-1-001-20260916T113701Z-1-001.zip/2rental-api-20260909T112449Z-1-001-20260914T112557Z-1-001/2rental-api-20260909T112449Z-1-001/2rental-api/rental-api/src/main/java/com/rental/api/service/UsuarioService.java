package com.rental.api.service;

import com.rental.api.exception.BusinessException;
import com.rental.api.exception.ResourceNotFoundException;
import com.rental.api.model.Usuario;
import com.rental.api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    public Usuario buscarPorId(Integer id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario nao encontrado com id: " + id));
    }

    public Usuario criar(Usuario usuario) {
        usuarioRepository.findByEmail(usuario.getEmail()).ifPresent(u -> {
            throw new BusinessException("Ja existe um usuario com o email: " + usuario.getEmail());
        });
        usuario.setIdUsuario(null);
        return usuarioRepository.save(usuario);
    }

    public Usuario atualizar(Integer id, Usuario dadosAtualizados) {
        Usuario usuario = buscarPorId(id);

        usuarioRepository.findByEmail(dadosAtualizados.getEmail())
                .filter(u -> !u.getIdUsuario().equals(id))
                .ifPresent(u -> {
                    throw new BusinessException("Ja existe outro usuario com o email: " + dadosAtualizados.getEmail());
                });

        usuario.setNome(dadosAtualizados.getNome());
        usuario.setEmail(dadosAtualizados.getEmail());
        return usuarioRepository.save(usuario);
    }

    public void excluir(Integer id) {
        Usuario usuario = buscarPorId(id);
        usuarioRepository.delete(usuario);
    }
}
