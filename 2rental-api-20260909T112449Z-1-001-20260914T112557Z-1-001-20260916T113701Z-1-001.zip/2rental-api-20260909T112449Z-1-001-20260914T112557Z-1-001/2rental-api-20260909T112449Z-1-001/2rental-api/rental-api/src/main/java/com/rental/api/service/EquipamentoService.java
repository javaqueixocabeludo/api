package com.rental.api.service;

import com.rental.api.exception.ResourceNotFoundException;
import com.rental.api.model.Categoria;
import com.rental.api.model.Equipamento;
import com.rental.api.repository.EquipamentoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EquipamentoService {

    private final EquipamentoRepository equipamentoRepository;
    private final CategoriaService categoriaService;

    public EquipamentoService(EquipamentoRepository equipamentoRepository, CategoriaService categoriaService) {
        this.equipamentoRepository = equipamentoRepository;
        this.categoriaService = categoriaService;
    }

    public List<Equipamento> listarTodos() {
        return equipamentoRepository.findAll();
    }

    public Equipamento buscarPorId(Integer id) {
        return equipamentoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Equipamento nao encontrado com id: " + id));
    }

    public List<Equipamento> listarPorCategoria(Integer idCategoria) {
        categoriaService.buscarPorId(idCategoria);
        return equipamentoRepository.findByCategoria_IdCategoria(idCategoria);
    }

    public List<Equipamento> listarComEstoqueBaixo() {
        return equipamentoRepository.findComEstoqueBaixo();
    }

    public Equipamento criar(Equipamento equipamento) {
        Categoria categoria = categoriaService.buscarPorId(equipamento.getCategoria().getIdCategoria());
        equipamento.setIdEquipamento(null);
        equipamento.setCategoria(categoria);
        return equipamentoRepository.save(equipamento);
    }

    public Equipamento atualizar(Integer id, Equipamento dadosAtualizados) {
        Equipamento equipamento = buscarPorId(id);
        Categoria categoria = categoriaService.buscarPorId(dadosAtualizados.getCategoria().getIdCategoria());

        equipamento.setNome(dadosAtualizados.getNome());
        equipamento.setMarca(dadosAtualizados.getMarca());
        equipamento.setModelo(dadosAtualizados.getModelo());
        equipamento.setPotencia(dadosAtualizados.getPotencia());
        equipamento.setMaterial(dadosAtualizados.getMaterial());
        equipamento.setPeso(dadosAtualizados.getPeso());
        equipamento.setDimensoes(dadosAtualizados.getDimensoes());
        equipamento.setCor(dadosAtualizados.getCor());
        equipamento.setQuantidadeDisponivel(dadosAtualizados.getQuantidadeDisponivel());
        equipamento.setQuantidadeMinima(dadosAtualizados.getQuantidadeMinima());
        equipamento.setCategoria(categoria);

        return equipamentoRepository.save(equipamento);
    }

    public void excluir(Integer id) {
        Equipamento equipamento = buscarPorId(id);
        equipamentoRepository.delete(equipamento);
    }
}
