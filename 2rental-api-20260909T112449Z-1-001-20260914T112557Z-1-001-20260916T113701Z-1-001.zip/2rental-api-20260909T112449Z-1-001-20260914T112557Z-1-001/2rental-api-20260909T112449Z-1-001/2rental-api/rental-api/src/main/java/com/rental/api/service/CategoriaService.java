package com.rental.api.service;

import com.rental.api.exception.ResourceNotFoundException;
import com.rental.api.model.Categoria;
import com.rental.api.repository.CategoriaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public List<Categoria> listarTodas() {
        return categoriaRepository.findAll();
    }

    public Categoria buscarPorId(Integer id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Categoria nao encontrada com id: " + id));
    }

    public Categoria criar(Categoria categoria) {
        categoria.setIdCategoria(null);
        return categoriaRepository.save(categoria);
    }

    public Categoria atualizar(Integer id, Categoria dadosAtualizados) {
        Categoria categoria = buscarPorId(id);
        categoria.setNome(dadosAtualizados.getNome());
        return categoriaRepository.save(categoria);
    }

    public void excluir(Integer id) {
        Categoria categoria = buscarPorId(id);
        categoriaRepository.delete(categoria);
    }
}
