ALTER TABLE usuarios ADD COLUMN senha VARCHAR(100);

UPDATE usuarios SET senha = '123456' WHERE email = 'carlos@email.com';
UPDATE usuarios SET senha = '123456' WHERE email = 'ana@email.com';
UPDATE usuarios SET senha = '123456' WHERE email = 'joao@email.com';
